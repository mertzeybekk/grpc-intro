package com.mert.client;

import com.mert.server.BankService;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BankClientTest {
    private com.mert.models.BankServiceGrpc.BankServiceBlockingStub bankServiceBlockingStub;

    @BeforeAll
    public void setUp() {
        ManagedChannel managedChannel = ManagedChannelBuilder.forAddress("localhost", 6565)
                .usePlaintext()
                .build();
        this.bankServiceBlockingStub = com.mert.models.BankServiceGrpc.newBlockingStub(managedChannel);
    }

    @Test
    public void balanceTest() {
        com.mert.models.BalanceCheckRequest balanceCheckRequest =
                com.mert.models.BalanceCheckRequest.newBuilder()
                        .setAccountNumber(12)
                        .build();
        com.mert.models.Balance balance = this.bankServiceBlockingStub.getBalance(balanceCheckRequest);
        System.out.println("Received : " + balance.getAmount());
    }
}
